### Hexlet tests and linter status:
[![Actions Status](https://github.com/Tivka8901/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Tivka8901/python-project-49/actions)
#запуск игры:
[![asciicast](https://asciinema.org/a/U5tG8PZjfCDF2N0QKVRd8Nuis.svg)](https://asciinema.org/a/U5tG8PZjfCDF2N0QKVRd8Nuis)
#Как выглядит победа:
[![asciicast](https://asciinema.org/a/xOpK7p1rEVaU74bZMfpHfEVeF.svg)](https://asciinema.org/a/xOpK7p1rEVaU74bZMfpHfEVeF)
#Как выглядит поражение:
[![asciicast](https://asciinema.org/a/IDS3zwFTQQnWbWOCPwkWObfqa.svg)](https://asciinema.org/a/IDS3zwFTQQnWbWOCPwkWObfqa)
#Играем 
[![asciicast](https://asciinema.org/a/A6B90bwZdRqVABxQoOJilQigI.svg)](https://asciinema.org/a/A6B90bwZdRqVABxQoOJilQigI)
#Как-то так
[![asciicast](https://asciinema.org/a/d0vdsa5UQPV3KyA7VTNQXvuX2.svg)](https://asciinema.org/a/d0vdsa5UQPV3KyA7VTNQXvuX2)
#Снова играем в новую игру!
[![asciicast](https://asciinema.org/a/8quc6z9y0Afc3b5QF4jzEJfQz.svg)](https://asciinema.org/a/8quc6z9y0Afc3b5QF4jzEJfQz)