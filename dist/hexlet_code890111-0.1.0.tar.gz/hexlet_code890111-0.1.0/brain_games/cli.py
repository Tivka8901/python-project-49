#приветствие пользователя
def welcome_user():
    print("Welcom ot the barain games!")
    name = input("May I have your name? ")
    print(f'Hello, {name}!')