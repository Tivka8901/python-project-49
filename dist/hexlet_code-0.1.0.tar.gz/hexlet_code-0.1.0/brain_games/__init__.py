def play_even_games():
    return None