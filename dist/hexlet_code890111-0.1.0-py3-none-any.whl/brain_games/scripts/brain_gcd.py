#!/usr/bin/env python3
from brain_games.games.gcd import play_gcd_game


def main():
    play_gcd_game()


if __name__ == '__main__':
    main()
