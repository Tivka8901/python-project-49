#приветствие пользователя
def welcom_user():
    print("Welcom ot the barain games!")
    name = input("May I have your name? ")
    print(f'Hello, {name}!')


def welcome_user():
    return None